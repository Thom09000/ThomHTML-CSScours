J'ai rajouté Prénom après nom dans le formulaire car cela me semble mieux pour identifier la personne au cas où elle mettrait du contenu problématique dans son message, par exemple.

La couleur demandé pour les "hover", en bleu intense, me semble peu UX.

Dans la consigne, la couleur #facc15 est demandée "pour styliser des éléments graphique mineur et pour les champs ciblés", toutefois elle tranche tellement et est tellement peu esthétique avec le fond demandé que j'ai eut du mal à l'utiliser, même avec parcimonie
Je l'ai donc juste utilisée en responsive.

Pour les boutons hover, en plus du bleu, j'ai rajouté un léger flou, cependant pour un vrai site je ne le ferais pas car ce n'est pas ux et pas bien pour l'accessibilité, c'ast uste là car c'est un contexte d'essaie du maximum de fonctionnalité

Pour la navbarre et le footer j'ai choisi des couleur de blanc cassé avec des ton chaud pour rester dans le thème tout en améliorant l'experience utilisateur et en efitant un site maussade, monotone, trop délavé, trop non hospitalié.